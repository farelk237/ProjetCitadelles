package modele;

import java.util.Scanner;

public class Condottiere extends Personnage {

    // Constructeur par défaut
    public Condottiere() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Condottiere", 8, Caracteristiques.CONDOTTIERE);
    }

    @Override
    public void utiliserPouvoir() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Voulez-vous utiliser votre pouvoir de destruction ? (o/n) ");
        char choix = scanner.next().charAt(0);

        if (Character.toLowerCase(choix) == 'o') {
            afficherCitadellesAdversaires(); // Affiche les citadelles des joueurs adverses

            System.out.print("Quel joueur choisissez-vous ? (0 pour ne rien faire) ");
            int choixJoueur = scanner.nextInt();

            if (choixJoueur > 0 && choixJoueur <= getPlateau().getNombreJoueurs()) {
                Joueur joueurChoisi = getPlateau().getJoueur(choixJoueur - 1);

                System.out.println("Voici la liste des quartiers dans la cité de " + joueurChoisi.getNom() + " :");
                afficherQuartiers(joueurChoisi.getCite());

                System.out.print("Quel quartier choisissez-vous ? ");
                int choixQuartier = scanner.nextInt();

                Quartier quartierChoisi = joueurChoisi.getCite()[choixQuartier - 1];
                System.out.println(quartierChoisi.getCout());
                int coutDestruction = quartierChoisi.getCout();

                if (getJoueur().nbPieces() >= coutDestruction) {
                    getJoueur().retirerPieces(coutDestruction);
                    joueurChoisi.retirerQuartierDansCite(quartierChoisi.getNom());
                    System.out.println("Vous avez détruit le quartier " + quartierChoisi.getNom() + " de " + joueurChoisi.getNom() + ".");
                } else {
                    System.out.println("Votre trésor n'est pas suffisant pour détruire ce quartier.");
                }
            } else {
                System.out.println("Choix invalide. Aucun quartier n'a été détruit.");
            }
        } else {
            System.out.println("Vous avez choisi de ne rien faire.");
        }
    }

    private void afficherCitadellesAdversaires() {
        System.out.println("Voici les citadelles des joueurs adverses :");
        for (int i = 0; i < getPlateau().getNombreJoueurs(); i++) {
            if (getPlateau().getJoueur(i) != getJoueur()) {
                Joueur joueurAdverse = getPlateau().getJoueur(i);
                System.out.println((i + 1) + " " + joueurAdverse.getNom() + ": ");
                afficherQuartiers(joueurAdverse.getCite());
            }
        }
    }

    private void afficherQuartiers(Quartier[] citadelle) {
        for (int i = 0; i < citadelle.length; i++) {
            if (citadelle[i] != null) {
                System.out.println((i + 1) + " " + citadelle[i].getNom() + "(coût " + citadelle[i].getCout() + ")");
            }
        }
    }

    @Override
    public void percevoirRessourcesSpecifiques() {
        int compteur = 0;
        if (!getAssassine()) {
            for (Quartier unQuartier : getJoueur().getCite()) {
                if (unQuartier != null && "MILITAIRE".equals(unQuartier.getType())) {
                    compteur++;
                }
            }
            getJoueur().ajouterPieces(compteur);
        }
    }
}
